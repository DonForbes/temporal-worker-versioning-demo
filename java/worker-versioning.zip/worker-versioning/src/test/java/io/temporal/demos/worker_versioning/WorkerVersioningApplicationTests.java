package io.temporal.demos.worker_versioning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkerVersioningApplicationTests {

	@Test
	void contextLoads() {
	}

}
