package io.temporal.demos.worker_versioning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkerVersioningApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkerVersioningApplication.class, args);
	}

}
